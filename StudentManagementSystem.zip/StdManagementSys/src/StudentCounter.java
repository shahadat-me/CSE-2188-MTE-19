
import com.mysql.jdbc.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StudentCounter {
    public static int countData(String tableName) {
        
        int total = 0;
        Connection con = MyConnection.getConnection();
        
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT COUNT(*) AS 'total' FROM " + tableName);
            while(rs.next())
            {
                total = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentCounter.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return total;
        
    }
    
    public static int countDataReg(String tableName) {
        
        int total = 0;
        Connection con = MyConnection.getConnection();
        
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT COUNT(*) AS 'total' FROM " + tableName);
            while(rs.next())
            {
                total = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentCounter.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return total;
        
    }
    
}
