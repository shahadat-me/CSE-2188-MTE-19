import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.JTable;
    
import  javax.swing.table.DefaultTableModel;
public class StudentInfo 
{
    public void IUDstudent(char operation, Integer id, String fname, String lname, String gender, String phone, String address, String roll)
    {
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        if(operation=='i')
        {
            try {
                ps = con.prepareStatement("INSERT INTO `studentinfo`(`FirstName`, `LastName`, `Gender`,  `Phoneno`, `Address`, `RollNo`) VALUES (?,?,?,?,?,?)");
                ps.setString(1, fname);
                 ps.setString(2, lname);
                  ps.setString(3, gender);
                    ps.setString(4, phone);
                     ps.setString(5, address);
                      ps.setString(6, roll);
                     
                  if( ps.executeUpdate()>0)
                  {
                   JOptionPane.showMessageDialog(null, "New Student Added");
                  }
            
            
            } catch (SQLException ex) {
                Logger.getLogger(StudentInfo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
        if(operation=='u')
        {
            try {
                ps = con.prepareStatement("UPDATE `studentinfo` SET `FirstName`= ?,`LastName`=? ,`Gender`=? ,`Phoneno`=? ,`Address`=? ,`RollNo`=? WHERE `ID`=?");
                ps.setString(1, fname);
                 ps.setString(2, lname);
                  ps.setString(3, gender);
                    ps.setString(4, phone);
                     ps.setString(5, address);
                      ps.setString(6, roll);
                      ps.setInt(7, id);
                     
                  if( ps.executeUpdate()>0)
                  {
                   JOptionPane.showMessageDialog(null, "Data Update Successful");
                  }
            
            
            } catch (SQLException ex) {
                Logger.getLogger(StudentInfo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
         if(operation=='r')
        {
            try {
                ps = con.prepareStatement("DELETE FROM `studentinfo` WHERE `ID` = ?");
                      ps.setInt(1, id);
                     
                  if( ps.executeUpdate()>0)
                  {
                   JOptionPane.showMessageDialog(null, "Removal Complete");
                  }
            
            
            } catch (SQLException ex) {
                Logger.getLogger(StudentInfo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    public void fillstudentJtable(JTable table ,String valueToSearch )
        {
            Connection con =MyConnection.getConnection();
            PreparedStatement ps;
        try {
            ps=con.prepareStatement("SELECT * FROM `studentinfo` WHERE CONCAT('FirstName','LastName','Gender','Phoneno','Address','RollNo') LIKE ? ");
            ps.setString(1,"%"+valueToSearch+"%");
            
            ResultSet rs =ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel)table.getModel();
            
            Object[] row;
            while (rs.next())
            { row=new Object[7];
            row[0]=rs.getInt(1);
            row[1]=rs.getString(2);
            row[2]=rs.getString(3);
            row[3]=rs.getString(4);
           
            row[4]=rs.getString(5);
            row[5]=rs.getString(6);
            row[6]=rs.getInt(7);
            
            model.addRow(row);
            
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentInfo.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

   public void CourseregJtable(JTable table ,String valueToSearch )
        {
            Connection con =MyConnection.getConnection();
            PreparedStatement ps;
        try {
            ps=con.prepareStatement("SELECT * FROM `coursereg` WHERE CONCAT(`ID`, `CourseNo`, `Credit`, `HoursPerWeek`) LIKE ? ");
            ps.setString(1,"%"+valueToSearch+"%");
            
            ResultSet rs =ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel)table.getModel();
            
            Object[] row;
            while (rs.next())
            { row=new Object[4];
            
            row[0]=rs.getInt(1);
            row[1]=rs.getString(2);
            row[2]=rs.getInt(3);
            row[3]=rs.getInt(4);
        
            
            model.addRow(row);
            
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentInfo.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }
   
   public void ResultJtable(JTable table ,String valueToSearch )
        {
            Connection con =MyConnection.getConnection();
            PreparedStatement ps;
        try {
            ps=con.prepareStatement("SELECT * FROM `result` WHERE CONCAT(`StudentRoll`, `CourseNo`, `CGPA`, `Grade`) LIKE ? ");
            ps.setString(1,"%"+valueToSearch+"%");
            
            ResultSet rs =ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel)table.getModel();
            
            Object[] row;
            while (rs.next())
            { row=new Object[4];
            row[0]=rs.getInt(1);
            row[1]=rs.getString(2);
            row[2]=rs.getInt(3);
            row[3]=rs.getString(4);
           
          
            
            model.addRow(row);
            
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentInfo.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
        
 } 