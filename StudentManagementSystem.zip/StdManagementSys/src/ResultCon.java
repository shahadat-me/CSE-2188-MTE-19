import com.mysql.jdbc.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class ResultCon {

    /**
     *
     * @param operation
     * @param roll
     * @param course
     * @param credit
     * @param grade
     */
    public void IUDstudent(char operation,  Integer roll, String course, Float credit,String grade )
    {
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        if(operation=='i')
        {
            try {
                ps=con.prepareStatement("INSERT INTO `result`( `StudentRoll`, `CourseNo`, `CGPA`, `Grade`) VALUES ( ?,?,?,?)");
               ps.setInt(1, roll);
                ps.setString(2, course);
                 ps.setFloat(3, credit);
                  ps.setString(4, grade);
                
                   
                     
                  if( ps.executeUpdate()>0)
                  {
                   JOptionPane.showMessageDialog(null, "Data submission succesful!");
                  }
            
            
            } catch (SQLException ex) {
                Logger.getLogger(StudentInfo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
