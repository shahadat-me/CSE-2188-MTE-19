//import com.mysql.jdbc.*;
//import java.sql.Connection;
import com.mysql.jdbc.Connection;

import java.sql.DriverManager;
//import javax.swing.JOptionPane;

public class MyConnection 
{
    public static Connection getConnection()
    {
        Connection con = null;
        
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
           con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/studentmanagementsystem", "root", "");
                    
            //con = DriverManager.getConnection("jdbc:mysql://localhost:8080/student management system?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
        
                    } catch (Exception ex) {System.out.println(ex.getMessage());
        }
        
        return con;
    }

   
}