
import com.mysql.jdbc.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class course {
    public void IUDstudent(char operation, Integer id, String course, Integer credit,Integer hours )
    {
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        if(operation=='i')
        {
            try {
                ps=con.prepareStatement("INSERT INTO `coursereg`( `CourseNo`, `Credit`, `HoursPerWeek`) VALUES (  ?,?,?)");
                ps.setString(1, course);
                 ps.setInt(2, credit);
                  ps.setInt(3, hours);
                   
                     
                  if( ps.executeUpdate()>0)
                  {
                   JOptionPane.showMessageDialog(null, "New Course Added");
                  }
            
            
            } catch (SQLException ex) {
                Logger.getLogger(StudentInfo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
